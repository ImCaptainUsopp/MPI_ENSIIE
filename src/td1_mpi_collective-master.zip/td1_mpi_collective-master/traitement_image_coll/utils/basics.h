#ifndef TP_BASICS_H
#define TP_BASICS_H

#define N_COMPONENT 3    // we have 3 component (RGB)
#define FULL        255

#endif

